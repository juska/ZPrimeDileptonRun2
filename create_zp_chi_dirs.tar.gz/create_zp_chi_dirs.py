# This python script is for creating data cards and directories
# for all the mass combinations for the Z' to ttbar analysis.
# We need to scan in mass of Z' (DM mediator) and Chi (DM particle) for
# spin-1 axial-vector (A1) and vector (V1) mediator scenarios.
# First developer: juska@cern.ch with instructions from Ia Iashvili
# Dev started: 17 July 2020
#
# Note that you must have a directory named 'datacards' in the working directory
# and the datacard templates inside this directory, named like this:
#
# customizecards.dat
# extramodels.dat
# madspin_card.dat
# proc_card.dat
# run_card.dat
#
# Run as: 'python create_zp_chi_dirs.py'



import os, sys, subprocess

# Give a path to datacard templates here
datacard_dir = "datacards"

# Masses in GeV
mchi = [10,50,100,1000]
mZp = [500,1000,2000,2500,3000,3500,4000]
scenarios = ["A1","V1"]

print "Please make sure that you have the datacard templates in %s/ -directory."\
    % datacard_dir
print "They should be named like this:"
os.system('ls -1 %s' %datacard_dir)

# Let's make a new directory from user input to avoid messing up the WD
proj_dir = raw_input("Please give a name for the project directory: ")

# Check if the directory exists and quit if so. Safety first!
if os.path.exists(proj_dir):
    print "Fatal error: a directory or file with the same name already exists!"
    sys.exit()

os.system('mkdir %s' % proj_dir)
os.chdir(proj_dir)

print "Creating directories"
# Let's make a triple-nested loop for making all the combinations at once
for chimass in mchi:
    for zpmass in mZp:
        for sc in scenarios:

            # Form dir name and make dir
            dir_name_beg = "ttbarReso__inclusive__DMsimp_s_spin1__"
            dir_name_end = "mchi_%i_mZp_%i_Benchmark%s" % (chimass,zpmass,sc)
            dir_name = dir_name_beg + dir_name_end
            os.system('mkdir %s' % dir_name)
            os.chdir(dir_name)
            
            is_last = mchi.index(chimass) == len(mchi)-1 and \
                mZp.index(zpmass) == len(mZp)-1 and \
                scenarios.index(sc) == len(scenarios)-1
            
            if is_last: 
                print "Directories created into %s/ for all combinations" \
                % proj_dir

            # Copy data cards over and rename them
            os.system('cp ../../%s/*.dat .' % (datacard_dir))
            os.system('rename s/^/%s_/ *.dat' % (dir_name))
            
            if is_last:
                print "Data card files copied and renamed"
            
            # Now let's modify proc_card.dat and customizecards.dat with sed
            # First the easy piecy, the proc_card
            oldline_proc = "output ttbarReso_DMsimp_s_spin1 -nojpeg"
            newline_proc = "output %s -nojpeg" % dir_name
            sed_cmd_proc = "sed -i 's/%s/%s/g' *proc_card.dat" \
               % (oldline_proc, newline_proc)
            os.system(sed_cmd_proc)

            # Now the easy part of customizecards, changing the masses
            oldline_cust_chi = "set param_card MASS  52 10"
            newline_cust_chi = "set param_card MASS  52 %i" % chimass
            os.system("sed -i 's/%s/%s/g' *izecards.dat" \
                % (oldline_cust_chi, newline_cust_chi))
            
            oldline_cust_zp = "set param_card MASS  55 1000"
            newline_cust_zp = "set param_card MASS  55 %i" % zpmass
            os.system("sed -i 's/%s/%s/g' *izecards.dat" \
                % (oldline_cust_zp, newline_cust_zp))
                
            # Done!!1. Now let's change the couplings for the A1 scenario
            if sc == "A1":
                
                # Run out of creativity with regexp, going old school..
                os.system("sed -i 's/gVd11 0.25/gVd11 0.0/' *izecards.dat")
                os.system("sed -i 's/gVu11 0.25/gVu11 0.0/' *izecards.dat")
                os.system("sed -i 's/gVd22 0.25/gVd22 0.0/' *izecards.dat")
                os.system("sed -i 's/gVu22 0.25/gVu22 0.0/' *izecards.dat")
                os.system("sed -i 's/gVd33 0.25/gVd33 0.0/' *izecards.dat")
                os.system("sed -i 's/gVu33 0.25/gVu33 0.0/' *izecards.dat")
                os.system("sed -i 's/gAd11 0.0/gAd11 0.25/' *izecards.dat")
                os.system("sed -i 's/gAu11 0.0/gAu11 0.25/' *izecards.dat")
                os.system("sed -i 's/gAd22 0.0/gAd22 0.25/' *izecards.dat")
                os.system("sed -i 's/gAu22 0.0/gAu22 0.25/' *izecards.dat")
                os.system("sed -i 's/gAd33 0.0/gAd33 0.25/' *izecards.dat")
                os.system("sed -i 's/gAu33 0.0/gAu33 0.25/' *izecards.dat")
            
            if is_last:
                print "'proc_card.dat' and 'customizecards.dat' modified "\
                     "successfully"
            
            # Remember to move back up before the next iteration!!
            os.chdir("..")

print "Mission accomplished, see %s/ for the results. Happy generating!" \
    % proj_dir
            
            









